.onAttach <- function(...){
  packageStartupMessage("\n rt.test Package is installed. \n\n")
}
