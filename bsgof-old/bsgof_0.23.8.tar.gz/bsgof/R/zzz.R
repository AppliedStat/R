.onAttach <- function(...){
  packageStartupMessage("\n bpgof Package is installed. \n\n")
}
